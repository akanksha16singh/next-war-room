# NEXT — Cultural War Room prototype

A front-end prototype of a decision layer: a signal arrives, six specialist agents argue it
out, a permissions engine decides who is allowed to act, a person approves, and an
append-only ledger remembers the outcome.

Everything currently shown is **seeded fixture data**. There is no backend yet.

## Live demo

https://USERNAME.github.io/REPO-NAME/

| Page | Path |
|---|---|
| Landing | `/` |
| Command Centre — full decision loop | `/command-centre/` |
| War Room — single moment under pressure | `/war-room/` |
| Command Centre (unbundled source build) | `/command-centre-src/` |

## Running it locally

There is no build step, but the pages must be served over HTTP — opening the files
directly with `file://` will break the source builds.

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

## Notes

- Layouts assume a desktop window of roughly 1400px and wider.
- `command-centre/index.html` is fully bundled and self-contained.
  `war-room/` and `command-centre-src/` each need their own copy of `support.js`,
  which is why the file appears twice.
- React and the web fonts load from public CDNs, so the pages need an internet connection.
- `.nojekyll` stops GitHub Pages from running the files through Jekyll.

## Docs

- [`docs/NEXT_OpenSpec_Build_Kit.md`](docs/NEXT_OpenSpec_Build_Kit.md) — product decision, master prompt, build sequence
- [`docs/claude-code-brief-live-backend.md`](docs/claude-code-brief-live-backend.md) — brief for putting a real backend behind this
